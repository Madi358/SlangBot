from aiogram.fsm.state import State, StatesGroup

class SlangStates(StatesGroup):
    waiting_for_slang = State() 